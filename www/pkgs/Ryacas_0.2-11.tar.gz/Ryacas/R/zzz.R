
.onLoad <- function(lib, pkg, ...) {
   Sys.setenv(YACAS_INVOKE_STRING =
   paste("java -jar",system.file("yacdir/yacas.jar", package = "Ryacas"))
   #paste("java -cp",system.file("yacdir/mathpiper.jar", package = "Ryacas"),
	#"org.mathpiper.ui.text.consoles.Console")
   )
   if (.Platform$OS.type != "windows") return()

   if (!file.exists(yacasFile("yacas.exe")) ||  
       !file.exists(yacasFile("scripts.dat"))) {
	cat(yacasFile("yacas.exe"), "\n   or", yacasFile("scripts.dat"), 
           "\n   not found.\n")
        cat("Run yacasInstall() without arguments to install yacas.\n")
   }

   invisible()
}
