### R code from vignette source 'Ryacas.Rnw'

