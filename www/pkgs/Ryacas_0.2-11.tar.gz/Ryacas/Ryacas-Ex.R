pkgname <- "Ryacas"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
library('Ryacas')

base::assign(".oldSearch", base::search(), pos = 'CheckExEnv')
cleanEx()
nameEx("Eval")
### * Eval

flush(stderr()); flush(stdout())

### Name: Eval
### Title: Evaluate a yacas expression.
### Aliases: Eval Eval.Sym Eval.Expr Eval.yacas
### Keywords: symbolmath

### ** Examples

## Not run: 
##D Eval(yacas(expression(x*x)), list(x=2))
##D 
##D # same
##D x <- 2
##D Eval(yacas(expression(x*x)))
## End(Not run)



cleanEx()
nameEx("Ryacas-package")
### * Ryacas-package

flush(stderr()); flush(stdout())

### Name: Ryacas-package
### Title: R interface to yacas computer algebra package
### Aliases: Ryacas-package
### Keywords: programming

### ** Examples

## Not run: 
##D print(yacas(expression(integrate(1/x, x))))
##D print(yacas("Integrate(x)1/x"))
##D x <- Sym("x"); Integrate(1/x, x)
##D acos(Sym("1/2"))
## End(Not run)



cleanEx()
nameEx("Sym")
### * Sym

flush(stderr()); flush(stdout())

### Name: Sym
### Title: Sym
### Aliases: Sym Expr Exprq Ops.Expr Math.Expr deriv.Expr print.Expr
###   as.character.Expr as.Sym as.Sym.Expr as.Sym.yacas as.character.Sym
###   as.expression.Sym deriv.Sym Integrate OpenMath2R Ops.Sym Math.Sym
###   Ops.yacas.symbol print.Sym determinant.Sym print.yacas Sym SymExpr
###   trans transtab yacas.symbol.value yDeriv yFactorial yIntegrate yLimit
###   yrewrite yUnlist Simplify Factorial List Ver N Pi Clear Factor Expand
###   Taylor InverseTaylor PrettyForm TeXForm Precision Conjugate
###   PrettyPrinter Solve Newton Set Infinity I Limit Inverse
###   'as.Expr.formula ' 'Clear.Expr ' Clear.default 'Conjugate.Expr '
###   Conjugate.default 'determinant.Expr ' 'Expand.Expr ' Expand.default
###   Factor.Expr Factor.default 'Factorial.Expr ' 'Factorial.default '
###   'Integrate.Expr ' Integrate.default 'Inverse.Expr ' 'Inverse.default
###   ' 'InverseTaylor.default ' 'Limit.Expr ' Limit.default 'List.Expr '
###   'List.default ' 'N.Expr ' 'N.default ' 'Newton.Expr ' 'Newton.default
###   ' Precision.Expr 'Precision.default ' 'PrettyForm.Expr '
###   'PrettyForm.default ' PrettyPrinter.Expr 'PrettyPrinter.default '
###   Simplify.Expr Simplify.default 'Solve.Expr ' 'Solve.default '
###   'Taylor.Expr ' 'Taylor.default ' 'TeXForm.Expr ' 'TeXForm.default '
###   'Ver.Expr ' Ver.default Identity.default Identity Subst Subst.default
###   %Where% %Where%.default
### Keywords: symbolmath

### ** Examples

## Not run: 
##D x <- Sym("x")
##D x*x
##D Integrate(x*x, x)
##D Sym("##D 
##D 
##D acos(Sym("1/2"))
##D 
##D y <- Exprq(x)
##D y*y
##D deriv(y*y, y)
##D Exprq(acos(1/2))
## End(Not run)



cleanEx()
nameEx("bodyAsExpression")
### * bodyAsExpression

flush(stderr()); flush(stdout())

### Name: bodyAsExpression
### Title: Get body of function as an expression.
### Aliases: bodyAsExpression as.language
### Keywords: symbolmath

### ** Examples

## Not run: 
##D 
##D # construct an R function for the Burr probability density
##D # function (PDF) given the Burr cumulative distribution function (CDF)
##D BurrCDF <- function(x, c = 1, k = 1) 1-(1+x^c)^-k
##D 
##D # transfer CDF to yacas
##D yacas(BurrCDF)
##D 
##D # create a template for the PDF from the CDF
##D BurrPDF <- BurrCDF
##D 
##D # differentiate CDF and place resulting expression in body
##D body(BurrPDF) <- yacas(expression(deriv(BurrCDF(x,c,k))))[[1]]
##D 
##D # test out PDF
##D BurrPDF(1)
##D 
## End(Not run)




cleanEx()
nameEx("runYacas")
### * runYacas

flush(stderr()); flush(stdout())

### Name: runYacas
### Title: Run a yacas session directly.
### Aliases: runYacas
### Keywords: symbolmath

### ** Examples

## Not run: 
##D yacasRun()
## End(Not run)



cleanEx()
nameEx("yacas")
### * yacas

flush(stderr()); flush(stdout())

### Name: yacas
### Title: yacas interface
### Aliases: isConnection yacas.character yacas.expression yacas.function
###   yacas.formula yacas.yacas yacasInvokeString yacas as.expression.yacas
###   as.character.yacas addSemi haveYacas yacasStart yacasStop ynext
###   ySequence ysub yparse yAssignFunction
### Keywords: symbolmath

### ** Examples

## Not run: 
##D yacas(expression(Factor(x^2-1)))
##D exp1 <- expression(x^2 + 2 * x^2)
##D exp2 <- expression(2 * exp0)
##D exp3 <- expression(6 * pi * x)
##D exp4 <- expression((exp1 * (1 - sin(exp3))) / exp2)
##D print(yacas(exp4))
##D 
##D print(yacas("Version()")) # yacas version
##D 
##D # see demo("Ryacas-Function")
##D 
##D 
## End(Not run)



cleanEx()
nameEx("yacasInstall")
### * yacasInstall

flush(stderr()); flush(stdout())

### Name: yacasInstall
### Title: Install yacas files needed by Ryacas
### Aliases: yacasInstall yacasFile
### Keywords: symbolmath

### ** Examples

## Not run: 
##D Sys.getenv("YACAS_INVOKE_STRING")
##D Sys.getenv("YACAS_HOME")
##D Sys.getenv("YACAS_SCRIPTS")
##D system.file(package = "Ryacas", "yacdir")
##D yacasFile("yacas.exe")
##D yacasFile("scripts.dat")
##D yacasInstall()
## End(Not run)



cleanEx()
nameEx("yacmode")
### * yacmode

flush(stderr()); flush(stdout())

### Name: yacmode
### Title: yacmode interface
### Aliases: yacmode
### Keywords: symbolmath

### ** Examples

## Not run: 
##D yacmode()
##D  (x+y)^3-(x-y)^3
##D  Simplify(##D 
##D  q
## End(Not run)



### * <FOOTER>
###
base::cat("Time elapsed: ", proc.time() - base::get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
